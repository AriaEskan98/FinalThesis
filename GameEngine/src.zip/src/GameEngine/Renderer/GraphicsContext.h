#pragma once

namespace GameEngine {

	class GraphicsContext
	{
	public:
		virtual ~GraphicsContext() = default;

		virtual void Init() = 0;
		virtual void SwapBuffers() = 0;

		static Own<GraphicsContext> Create(void* window);
	};

}