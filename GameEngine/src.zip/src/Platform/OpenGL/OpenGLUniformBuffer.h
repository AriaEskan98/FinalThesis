#pragma once

#include "GameEngine/Renderer/UniformBuffer.h"

namespace GameEngine {

	class OpenGLUniformBuffer : public UniformBuffer
	{
	public:
		OpenGLUniformBuffer(uint32_t size, uint32_t binding);
		virtual ~OpenGLUniformBuffer();

		virtual void SetData(const void* data, uint32_t size, uint32_t offset = 0) override;
	private:
		uint32_t myRendererID = 0;
	};
}
